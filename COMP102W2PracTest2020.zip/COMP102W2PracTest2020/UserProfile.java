import java.util.*;

public class UserProfile {
  
  /* 5 marks */
  public UserProfile(
    String uId, 
    String fName,
    String lName,
    String ctry,
    int nFol
  ) {
    // CHANGE ME
  }
  
  public String getUserId() {
    return userId;
  }
  
  public int getNoOfFollowers() {
    return noOfFollowers;
  }
  
  public int getNoOfTweets() {
    return noOfTweets;
  }
  
  /* 15 marks */
  public void addTweet(String t) {
    // CHANGE ME
  }
  
  /* 10 marks */
  private String printTweets() {
    // CHANGE ME
  }
  
  public String toString() {
    return "ID: " + userId + "\n" + 
    "First Name: " + firstName + "\n" +
    "Last Name: " + lastName + "\n" + 
    "Country: " + country + "\n" + 
    "Followers: " + noOfFollowers + "\n" + 
    "# Tweets: " + noOfTweets + "\n" +
    "Tweets:\n" + printTweets();
  }
  
  private String userId;
  private String firstName;
  private String lastName;
  private String country;
  private int noOfFollowers;
  private int noOfTweets;
  private String[] tweets;
}
