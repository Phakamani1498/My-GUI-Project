import java.util.*;
import java.io.*;

public class TwitterReport {
  
  /*40 marks*/
  public static void main(String[] args) throws IOException {
    // CHANGE ME
  }
  
  /*15 marks*/
  private static UserProfile maxFollowers(UserProfile[] users) {
    // CHANGE ME
  }
  
  /*15 marks*/
  private static UserProfile maxTweets(UserProfile[] users) {
    // CHANGE ME
  }
}
